#ifndef BUTTON_KEY_FLOATING_AMLMOD_H
#define BUTTON_KEY_FLOATING_AMLMOD_H

#include <jni.h>
#include <stdint.h>
#include <stddef.h>

#if defined(__arm__)
    #define AML32
#elif defined(__aarch64__)
    #define AML64
#else
    #error "Button Key Floating: AML supports ARM ABIs only."
#endif

struct ModInfo {
    char guid[48];
    char name[48];
    char version[24];
    char author[48];

    ModInfo(const char* g, const char* n, const char* v, const char* a) {
        copy(guid, sizeof(guid), g);
        copy(name, sizeof(name), n);
        copy(version, sizeof(version), v);
        copy(author, sizeof(author), a);
    }

private:
    static void copy(char* dst, size_t cap, const char* src) {
        if (!dst || cap == 0) return;
        size_t i = 0;
        if (src) {
            for (; i + 1 < cap && src[i]; ++i) dst[i] = src[i];
        }
        dst[i] = '\0';
    }
};

/*
 * Opaque AML interface.
 * Button Key Floating v0.1 does not call AML methods yet, but keeps
 * the pointer for compatibility with the standard AML mod entry macro.
 */
struct IAML;

using GetInterfaceFn = void* (*)(const char*);

inline void* GetInterface(const char* name) {
    (void)name;
    return nullptr;
}

#define MYMOD(_guid, _name, _version, _author)                         \
    static ModInfo modinfoLocal(#_guid, #_name, #_version, #_author);  \
    ModInfo* modinfo = &modinfoLocal;                                  \
    extern "C" JNIEXPORT ModInfo* __GetModInfo() { return modinfo; }   \
    IAML* aml = nullptr;

#define ON_MOD_LOAD() \
    extern "C" JNIEXPORT void OnModLoad()

#endif
