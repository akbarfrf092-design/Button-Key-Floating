#ifndef BUTTON_KEY_FLOATING_LOGGER_H
#define BUTTON_KEY_FLOATING_LOGGER_H

#include <android/log.h>
#include <cstdarg>
#include <cstdio>

class Logger {
public:
    Logger() = default;

    void Info(const char* format, ...) {
        va_list args;
        va_start(args, format);
        log_v(ANDROID_LOG_INFO, format, args);
        va_end(args);
    }

    void Error(const char* format, ...) {
        va_list args;
        va_start(args, format);
        log_v(ANDROID_LOG_ERROR, format, args);
        va_end(args);
    }

private:
    static void log_v(int priority, const char* format, va_list args) {
        char buffer[2048];
        vsnprintf(buffer, sizeof(buffer), format ? format : "", args);
        __android_log_print(priority, "ButtonKeyFloating", "%s", buffer);
    }
};

inline Logger g_buttonKeyFloatingLogger;
inline Logger* logger = &g_buttonKeyFloatingLogger;

#endif
