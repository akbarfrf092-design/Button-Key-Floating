LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := button_key_floating
LOCAL_SRC_FILES := main.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/include
LOCAL_CPPFLAGS += -std=c++17
LOCAL_LDLIBS += -llog -ldl

include $(BUILD_SHARED_LIBRARY)
