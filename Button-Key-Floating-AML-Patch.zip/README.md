# Button Key Floating — AML build patch

This package adds the missing local headers required by the current
minimal Button Key Floating plugin and updates the NDK makefiles.

Files:
- app/include/mod/amlmod.h
- app/include/mod/logger.h
- app/Android.mk
- app/Application.mk
- app/main.cpp
- INSTALL.txt

Important:
These are lightweight project-local compatibility headers for the current
v0.1 plugin. They are intentionally not a copy of the full AML SDK.

The current main.cpp only needs:
- MYMOD()
- ON_MOD_LOAD()
- logger->Info()

The plugin does not call AML's IAML methods yet.

For the next build:
1. Upload/replace the files at the matching paths in GitHub.
2. Run the GitHub Actions workflow again.
3. If compilation reaches a new error, send the error screenshot/log.
